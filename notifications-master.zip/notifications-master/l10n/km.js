OC.L10N.register(
    "notifications",
    {
    "Notifications" : "ការ​ជូន​ដំណឹង"
},
"nplurals=1; plural=0;");
