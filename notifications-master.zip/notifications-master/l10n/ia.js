OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notificationes",
    "No notifications" : "Nulle notificationes",
    "Dismiss" : "Dimitter",
    "in {path}" : "in {path}"
},
"nplurals=2; plural=(n != 1);");
