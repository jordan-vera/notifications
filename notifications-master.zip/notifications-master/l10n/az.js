OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Xəbərdarlıqlar"
},
"nplurals=2; plural=(n != 1);");
