OC.L10N.register(
    "notifications",
    {
    "Notifications" : "বার্তাসমূহ"
},
"nplurals=2; plural=(n != 1);");
