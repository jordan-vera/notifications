OC.L10N.register(
    "notifications",
    {
    "Notifications" : "通知",
    "in {path}" : "在 {path}"
},
"nplurals=1; plural=0;");
