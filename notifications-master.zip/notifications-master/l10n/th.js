OC.L10N.register(
    "notifications",
    {
    "Notifications" : "การแจ้งเตือน",
    "Dismiss" : "ยกเลิก",
    "in {path}" : "ใน {เส้นทาง}"
},
"nplurals=1; plural=0;");
