OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Administratoriaus pranešimai",
    "Notifications" : "Pranešimai",
    "No notifications" : "Pranešimų nėra",
    "Failed to dismiss all notifications" : "Nepavyko atmesti visus pranešimus",
    "Failed to perform action" : "Nepavyko įvykdyti veiksmą",
    "Dismiss" : "Atmesti",
    "Failed to dismiss notification" : "Nepavyko atmesti pranešimą",
    "in {path}" : "nuorodoje {path}"
},
"nplurals=4; plural=(n % 10 == 1 && (n % 100 > 19 || n % 100 < 11) ? 0 : (n % 10 >= 2 && n % 10 <=9) && (n % 100 > 19 || n % 100 < 11) ? 1 : n % 1 != 0 ? 2: 3);");
