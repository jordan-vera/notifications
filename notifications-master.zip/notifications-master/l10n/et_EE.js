OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Märguanded",
    "No notifications" : "Märguandeid pole",
    "Dismiss" : "Jäta vahele",
    "in {path}" : "rajal {path}"
},
"nplurals=2; plural=(n != 1);");
