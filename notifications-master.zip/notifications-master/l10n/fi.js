OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Ylläpitoilmoitukset",
    "Notifications" : "Ilmoitukset",
    "Dismiss all notifications" : "Hylkää kaikki ilmoitukset",
    "No notifications" : "Ei ilmoituksia",
    "Failed to dismiss all notifications" : "Kaikki ilmoitusten hylkääminen epäonnistui",
    "Failed to perform action" : "Toimenpiteen suorittaminen epäonnistui",
    "Dismiss" : "Hylkää",
    "Failed to dismiss notification" : "Ilmoituksen hylkääminen epäonnistui",
    "in {path}" : "polussa {path}"
},
"nplurals=2; plural=(n != 1);");
