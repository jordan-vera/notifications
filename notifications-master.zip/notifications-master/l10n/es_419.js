OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notificaciones",
    "No notifications" : "No hay notificaciones",
    "Dismiss" : "Descartar",
    "in {path}" : "en {path}"
},
"nplurals=2; plural=(n != 1);");
