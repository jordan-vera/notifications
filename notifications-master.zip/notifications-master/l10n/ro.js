OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notificări",
    "No notifications" : "Nu sunt notificări",
    "Dismiss" : "Elimină",
    "in {path}" : "în {path}"
},
"nplurals=3; plural=(n==1?0:(((n%100>19)||((n%100==0)&&(n!=0)))?2:1));");
