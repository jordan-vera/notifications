OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Thông báo quản trị",
    "Notifications" : "Thông báo",
    "Dismiss all notifications" : "Bỏ qua tất cả thông báo",
    "No notifications" : "Không thông báo ",
    "Dismiss" : "Bỏ qua",
    "Failed to dismiss notification" : "Lỗi bỏ qua thông báo",
    "in {path}" : "trong {path}"
},
"nplurals=1; plural=0;");
