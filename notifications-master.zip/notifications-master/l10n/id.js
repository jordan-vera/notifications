OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Pemberitahuan",
    "No notifications" : "Tidak ada pemberitahuan",
    "Dismiss" : "Abaikan",
    "in {path}" : "di {path}"
},
"nplurals=1; plural=0;");
