OC.L10N.register(
    "notifications",
    {
    "in {path}" : "í {path}"
},
"nplurals=2; plural=(n != 1);");
