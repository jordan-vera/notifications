OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Adminu paziņojumi",
    "Notifications" : "Paziņojumi",
    "No notifications" : "Nav paziņojumu",
    "Dismiss" : "Atmest",
    "Failed to dismiss notification" : "Neizdevās atmest paziņojumu",
    "in {path}" : "{path}"
},
"nplurals=3; plural=(n%10==1 && n%100!=11 ? 0 : n != 0 ? 1 : 2);");
