OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Bildirishnomalar",
    "Dismiss" : "Tashlab qo'ymang"
},
"nplurals=1; plural=0;");
