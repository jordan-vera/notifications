OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Административни известия",
    "Notifications" : "Известия",
    "Dismiss all notifications" : "Откажи всички съобщения",
    "No notifications" : "Няма известия",
    "Failed to dismiss all notifications" : "Неуспешно отхвърляне на всичко известия",
    "Failed to perform action" : "Грешка при изпълнение на действие",
    "Dismiss" : "Отхвърляне",
    "Failed to dismiss notification" : "Неуспешен опит за отхвърляне на известие",
    "in {path}" : "в {path}"
},
"nplurals=2; plural=(n != 1);");
