OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Administratzailearen jakinarazpenak",
    "Notifications" : "Jakinarazpenak",
    "Dismiss all notifications" : "Baztertu jakinarazpen guztiak",
    "No notifications" : "Ez dago jakinarazpenik",
    "Failed to dismiss all notifications" : "Huts egin du jakinarazpen guztiak baztertzean",
    "Failed to perform action" : "Huts egin du ekintza burutzean",
    "Dismiss" : "Baztertu",
    "Failed to dismiss notification" : "Huts egin du jakinarazpena baztertzean",
    "in {path}" : "{path} -en"
},
"nplurals=2; plural=(n != 1);");
