OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "Notificações de administrador",
    "Notifications" : "Notificações",
    "Dismiss all notifications" : "Dispensar todas as notificações",
    "No notifications" : "Sem notificações",
    "Failed to dismiss all notifications" : "Falhou a dispensar todas as notificações",
    "Failed to perform action" : "Falhou a executar acção",
    "Dismiss" : "Dispensar",
    "Failed to dismiss notification" : "Falhou a dispensar notificação",
    "in {path}" : "em {path}"
},
"nplurals=2; plural=(n != 1);");
