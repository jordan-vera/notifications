OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notifikatiounen",
    "Dismiss" : "Ofbriechen",
    "in {path}" : "am [Pad]"
},
"nplurals=2; plural=(n != 1);");
