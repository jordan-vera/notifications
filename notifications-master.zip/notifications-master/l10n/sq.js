OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Njoftimet",
    "No notifications" : "Asnjë njoftim",
    "Dismiss" : "Hiq",
    "in {path}" : "në {path}"
},
"nplurals=2; plural=(n != 1);");
