OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Мэдэгдэл",
    "No notifications" : "Мэдэгдэл байхгүй",
    "Dismiss" : "Арилгах",
    "in {path}" : "{path}-д"
},
"nplurals=2; plural=(n != 1);");
