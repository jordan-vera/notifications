OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notificacions",
    "Dismiss" : "Ignorar"
},
"nplurals=2; plural=(n > 1);");
