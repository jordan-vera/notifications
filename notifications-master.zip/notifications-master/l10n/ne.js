OC.L10N.register(
    "notifications",
    {
    "in {path}" : "{path} मा"
},
"nplurals=2; plural=(n != 1);");
