OC.L10N.register(
    "notifications",
    {
    "Notifications" : "නිවේදන "
},
"nplurals=2; plural=(n != 1);");
