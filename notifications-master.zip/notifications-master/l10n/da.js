OC.L10N.register(
    "notifications",
    {
    "Notifications" : "Notifikationer",
    "No notifications" : "Ingen notifikationer",
    "Failed to perform action" : "Mislykkedes at udføre handling",
    "Dismiss" : "Afvis",
    "Failed to dismiss notification" : "Kunne ikke fjerne notifikation",
    "in {path}" : "i {path}"
},
"nplurals=2; plural=(n != 1);");
