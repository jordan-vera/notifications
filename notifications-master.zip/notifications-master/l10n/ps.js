OC.L10N.register(
    "notifications",
    {
    "in {path}" : "په {path} کې"
},
"nplurals=2; plural=(n != 1);");
