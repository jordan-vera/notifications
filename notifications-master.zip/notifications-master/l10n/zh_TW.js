OC.L10N.register(
    "notifications",
    {
    "Admin notifications" : "管理員通知",
    "Notifications" : "通知",
    "No notifications" : "沒有通知",
    "Failed to dismiss all notifications" : "關閉所有通知失敗",
    "Failed to perform action" : "採取動作失敗",
    "Dismiss" : "關閉",
    "Failed to dismiss notification" : "關閉通知失敗",
    "in {path}" : "在 {path}"
},
"nplurals=1; plural=0;");
